Place the data files inside a data folder and put that data folder and the two .py files in the same directory.
Simply the run the python files to display the results!

For convex.py to see the results for learned thetas uncomment the train lines from classifier() function.
