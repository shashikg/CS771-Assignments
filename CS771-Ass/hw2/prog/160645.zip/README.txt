- Put the data files in a folder /data/
- Use the global variables Qn and part to genrate different graphs.
Qn = 2 #Give 1 for different sigma case and 2 for same sigma case
part = 2 #Give 1 for part 1 and 2 for part 2

For SVM case scikit-learn package was used
